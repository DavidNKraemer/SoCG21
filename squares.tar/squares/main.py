import numpy as np

import pyglet
from pyglet.window import key, mouse
from pyglet import shapes, text
import pyglet.gl as gl


class BoardManager():

    def __init__(self, n_obstacles, n_bots, block_info, batch):

        self.n_obstacles = n_obstacles
        self.n_bots = n_bots
        self.n_blocks = block_info['n_blocks']
        self.block_size = block_info['block_size']

        self.batch = batch

        self.obstacles, self.targets, self.bots = [], [], []
        for i in range(self.n_obstacles):
            self.obstacles.append(self.get_box(label=f'Obs {i}', color=(0, 0, 0)))

        for i in range(self.n_bots):
            self.targets.append(self.get_box(label=f'Tar {i}', color=(0, 255, 0)))
            self.bots.append(self.get_box(label=f'Bot {i}', color=(0, 0, 255)))

    def get_box(self, label, color=None):
        if color is None:
            color = (55, 55, 255)

        x, y = np.random.randint(self.n_blocks, size=2) * self.block_size

        rectangle = shapes.Rectangle(
            x, y,
            self.block_size, self.block_size,
            color=color, batch=self.batch
        )

        rectangle.opacity = 100

        label = text.Label(
            label, font_name='Arial', font_size=10,
            color=(0, 0, 0, 255),
            x=x, y=y, batch=self.batch
        )

        return rectangle, label

    def move(self, dt):
        moves = np.array([(-1, 0), (0, -1), (0, 0), (1, 0), (0, 1)]) * self.block_size
        for (bot, label), (target, _) in zip(self.bots, self.targets):

            dx, dy = moves[np.random.choice(moves.shape[0])]

            bot.x += dx
            bot.y += dy
            label.x += dx
            label.y += dy


class App(pyglet.window.Window):

    def __init__(self, width, height, n_obstacles, n_bots, *args, **kwargs):
        super().__init__(width, height, *args, **kwargs)

        self.n_blocks = 20
        self.block_size = min(width, height) // self.n_blocks
        self.scale = 1.1
        self.speed = 1/5
        self.key_speed = 1/30
        self.translate_speed = 2 * self.speed * self.block_size

        self.sim_toggle = True


        self.current_scale = 1.
        self.max_scale = 2.
        self.min_scale = 0.1

        self.batch = pyglet.graphics.Batch()
        self.board_manager = BoardManager(
            n_obstacles,
            n_bots,
            dict(n_blocks=self.n_blocks, block_size=self.block_size),
            self.batch
        )

        self.schedule_method = self.board_manager.move
        self.key_handler = key.KeyStateHandler()
        self.push_handlers(self.key_handler)

        gl.glClearColor(255, 255, 255, 1.0)
        gl.glPushMatrix()

        self.print_help()

    def on_draw(self):
        self.clear()
        self.batch.draw()

    def on_key_press(self, symbol, modifiers):
        if symbol == key.ESCAPE:
            self.close()
        if symbol == key.SPACE:
            self.sim_toggle = not self.sim_toggle
            if self.sim_toggle:
                pyglet.clock.schedule_interval(self.schedule_method, self.speed)
            else:
                pyglet.clock.unschedule(self.schedule_method)

        if symbol == key.H:
            self.print_help()

        if symbol == key.SLASH:
            gl.glPopMatrix()
            gl.glPushMatrix()
            self.current_scale = 1.

    def print_help(self):
        char_pad = 10
        info_pad = 40

        arrows = {
            'right': '\u2192',
            'left': '\u2190',
            'up': '\u2191',
            'down': '\u2193',
        }

        instructions = {
            **{char: f'Move {direction}' for direction, char in arrows.items()},
            'h': 'Print viewer instructions',
            ',': 'Zoom in',
            '.': 'Zoom out',
            '/': 'Reset view',
            'SPACE': 'Pause/resume simulation'
        }

        print('\u250c' + '\u2500' * (char_pad + info_pad + 5) + '\u2510')
        print('\u2502' + "Viewer Instructions".center(char_pad + info_pad + 5) + '\u2502')
        print('\u251c' + '\u2500' * char_pad + '\u252c' + '\u2500' * (info_pad + 4) + '\u2524')
        for char, info in instructions.items():
            print('\u2502' + char.center(char_pad) + '\u2502' + '\t' + info.ljust(info_pad) + '\u2502')
        print('\u2514' + '\u2500' * char_pad + '\u2534' + '\u2500' * (info_pad + 4) + '\u2518')

    def update(self, _):
        speed = self.translate_speed / self.current_scale

        # translation keys
        if self.key_handler[key.UP]:
            gl.glTranslatef(0, -speed, 0)
        if self.key_handler[key.DOWN]:
            gl.glTranslatef(0, speed, 0)
        if self.key_handler[key.LEFT]:
            gl.glTranslatef(speed, 0, 0)
        if self.key_handler[key.RIGHT]:
            gl.glTranslatef(-speed, 0, 0)

        # zooming keys
        if self.key_handler[key.PERIOD]:  # out
            if self.current_scale > self.min_scale:
                gl.glScalef(1/self.scale, 1/self.scale, 1.)
                self.current_scale /= self.scale

        if self.key_handler[key.COMMA]:  # in
            if self.current_scale < self.max_scale:
                gl.glScalef(self.scale, self.scale, 1.)
                self.current_scale *= self.scale

    def run(self):
        pyglet.clock.schedule_interval(self.update, self.key_speed)
        pyglet.clock.schedule_interval(self.schedule_method, self.speed)
        pyglet.app.run()


if __name__ == '__main__':

    np.random.seed(0)
    app = App(1200, 600, n_obstacles=10, n_bots=5)
    app.run()

